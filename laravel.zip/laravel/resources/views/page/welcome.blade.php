@extends('main')
@section('content')
        <div class ="row"> 
            <div class = "col-md-12">
                <div class="jumbotron">
                    <h1>Hi {{ $fig }} Team! </h1>
                    <h2>Welcome to Gavin's Blog</h2>
                    <hr>
                    <p>Check out the blogs by clicking the button below which can only be updated by logging in...maybe...hmmm...yep im pretty sure you have to be logged in.</p>
                   
                    @if (Auth::check())
                        <p> <a class="btn btn-primary btn-lg" href="./posts" role="button">View Blogs</a> 
                        </p>
                    @else
                        <p> <a class="btn btn-primary btn-lg" href="./blog" role="button">View Blogs</a>
                        <a class="btn btn-primary btn-lg" href="./auth/login" role="button">Login</a>
                        <a class="btn btn-primary btn-lg" href="./auth/register" role="button">Register</a>
                        </p>
                    @endif
                    
                </div>
            </div>  
        </div> <!--End of row header -->

         <div class ="row"> 
            <div class = "col-md-8">
            </div>
             <div class = "col-md-3 col md-offset-1"></div>
        </div>
    </div>

@endsection
