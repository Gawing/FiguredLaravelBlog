<?php $__env->startSection('content'); ?>
        <div class ="row"> 
            <div class = "col-md-12">
                <div class="jumbotron">
                    <h1>Hi <?php echo e($fig); ?> Team! </h1>
                    <h2>Welcome to Gavin's Blog</h2>
                    <hr>
                    <p> </p>
                    <p><a class="btn btn-primary btn-lg" href="./login" role="button">Create a new blog/a></p>
                </div>
            </div>  
        </div> <!--End of row header -->

         <div class ="row"> 
            <div class = "col-md-8">

            </div>
             <div class = "col-md-3 col md-offset-1"></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>