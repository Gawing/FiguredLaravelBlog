<?php $__env->startSection('content'); ?>
        <div class ="row"> 
            <div class = "col-md-12">
                <div class="jumbotron">
                    <h1>Hi <?php echo e($fig); ?> Team! </h1>
                    <h2>Welcome to Gavin's Blog</h2>
                    <hr>
                    <p>Check out the blogs by clicking the button below which can only be updated by logging in...maybe...hmmm...yep im pretty sure you have to be logged in.</p>
                   
                    <?php if(Auth::check()): ?>
                        <p> <a class="btn btn-primary btn-lg" href="./posts" role="button">View Blogs</a> 
                        </p>
                    <?php else: ?>
                        <p> <a class="btn btn-primary btn-lg" href="./blog" role="button">View Blogs</a>
                        <a class="btn btn-primary btn-lg" href="./auth/login" role="button">Login</a>
                        <a class="btn btn-primary btn-lg" href="./auth/register" role="button">Register</a>
                        </p>
                    <?php endif; ?>
                    
                </div>
            </div>  
        </div> <!--End of row header -->

         <div class ="row"> 
            <div class = "col-md-8">
            </div>
             <div class = "col-md-3 col md-offset-1"></div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>