<?php

namespace App\Http\Controllers;

use App\Post;

class PageController extends Controller {

	public function getIndex(){		
		$fig = 'Figured';
		//$posts = Post::orderBy('created_at','desc')->limit(3)->get();
		//return view('page.welcome')->withFig($fig)->withPosts($posts);
		return view('page.welcome')->withFig($fig);
	}

}