<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\Post;

class BlogController extends Controller
{
    
	public function getIndex(){ 
		$fig = 'Figured';
		$posts = Post::all();
		return view('blog.index')->withPosts($posts)->withFig($fig);
	}
   
    public function getSingle($id){
    	$post = Post::find($id);
    	return view('blog.single')->withPost($post);
    }

}
